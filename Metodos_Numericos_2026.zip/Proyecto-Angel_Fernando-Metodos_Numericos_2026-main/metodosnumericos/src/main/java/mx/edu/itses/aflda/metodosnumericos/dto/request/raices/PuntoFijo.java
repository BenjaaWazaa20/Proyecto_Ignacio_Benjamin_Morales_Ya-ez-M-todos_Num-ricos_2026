package mx.edu.itses.aflda.metodosnumericos.dto.request.raices;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PuntoFijo {
    private double x0;
    private String fx;
    private String gx;
    private double er;
    private int maximoIteraciones;
}