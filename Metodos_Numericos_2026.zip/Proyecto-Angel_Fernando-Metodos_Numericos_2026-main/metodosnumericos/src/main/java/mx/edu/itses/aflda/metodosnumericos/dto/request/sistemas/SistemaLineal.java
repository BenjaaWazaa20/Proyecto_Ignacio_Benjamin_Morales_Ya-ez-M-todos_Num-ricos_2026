package mx.edu.itses.aflda.metodosnumericos.dto.request.sistemas;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SistemaLineal {
    private int tamano;
    private double[][] matriz;
    private double[] vector;
}