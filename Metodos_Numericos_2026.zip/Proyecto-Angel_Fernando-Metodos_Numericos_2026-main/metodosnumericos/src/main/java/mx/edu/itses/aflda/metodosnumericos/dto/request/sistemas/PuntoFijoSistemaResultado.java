package mx.edu.itses.aflda.metodosnumericos.dto.request.sistemas;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PuntoFijoSistemaResultado {
    private List<PuntoFijoSistemaRespuesta> historial; //[cite: 3]
    private boolean convergio; //[cite: 3]
    private double xFinal; //[cite: 3]
    private double yFinal; //[cite: 3]
    private String mensajeError; //[cite: 3]
}